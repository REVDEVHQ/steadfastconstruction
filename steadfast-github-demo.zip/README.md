# Steadfast Construction - Demo Website

Professional construction company website built for Seattle-based Steadfast Construction.

## Features
- Responsive design
- Modern UI/UX
- Contact form
- Project gallery
- Service showcase
- Client testimonials

## Live Demo
View the live site at: `https://yourusername.github.io/steadfast-construction`

## Technologies
- HTML5
- CSS3
- Vanilla JavaScript

## Setup
1. Fork this repository
2. Go to Settings > Pages
3. Select "main" branch
4. Click Save
5. Your site will be live in a few minutes!

---

Built with ❤️ for Steadfast Construction
